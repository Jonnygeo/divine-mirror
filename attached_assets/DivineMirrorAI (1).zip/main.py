from fastapi import FastAPI, Request
from pydantic import BaseModel
import os
import openai
from dotenv import load_dotenv
from fastapi.middleware.cors import CORSMiddleware
from langchain.embeddings.openai import OpenAIEmbeddings
from langchain.vectorstores import Chroma
from langchain.text_splitter import CharacterTextSplitter
from langchain.document_loaders import TextLoader
from langchain.chains.question_answering import load_qa_chain
from langchain.llms import OpenAI

# Load environment variables
load_dotenv()
openai.api_key = os.getenv("OPENAI_API_KEY")

# FastAPI App
app = FastAPI()

# Enable CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Request format
class QueryRequest(BaseModel):
    question: str

# Load documents (you can replace 'texts/jesus.txt' with your own data)
loader = TextLoader("texts/jesus.txt")
documents = loader.load()

# Split text into chunks
text_splitter = CharacterTextSplitter(chunk_size=1000, chunk_overlap=100)
texts = text_splitter.split_documents(documents)

# Create vector database
embeddings = OpenAIEmbeddings()
db = Chroma.from_documents(texts, embeddings)

# Load QA chain
llm = OpenAI(temperature=0)
qa_chain = load_qa_chain(llm, chain_type="stuff")

# System prompt for Divine Mirror AI
SYSTEM_PROMPT = """
You are Divine Mirror AI, an all-knowing agent of spiritual truth.
You do not preach, but you reveal. You compare the pure teachings of spiritual leaders
to the actions of institutions, empires, or modern religion. Always show primary sources and historic context.
Never favor a denomination or government. Expose manipulation without hate.
Honor love, humility, freedom, and human conscience as sacred.
"""

@app.post("/ask")
async def ask_question(request: QueryRequest):
    docs = db.similarity_search(request.question)
    answer = qa_chain.run(input_documents=docs, question=request.question)
    return {"answer": answer}

@app.get("/")
def read_root():
    return {"message": "Divine Mirror AI is live."}
