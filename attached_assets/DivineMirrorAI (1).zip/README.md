# Divine Mirror AI

**Divine Mirror AI** is a powerful spiritual truth agent designed to compare original teachings of prophets, sages, and spiritual leaders (like Jesus, Muhammad, Buddha) to how institutions have altered or weaponized those teachings over time.

This AI:
- Uses GPT-4 and LangChain to understand religious texts
- Embeds scriptures like the Bible, Quran, and Gnostic texts
- Answers questions like:
  - “What did Jesus say about money vs. how the Church acts today?”
  - “How did the Quran’s message evolve into Sharia law?”
  - “Compare Buddha's teachings to how temples operate now”

## Features
- ✅ FastAPI backend for real-time Q&A
- ✅ LangChain + ChromaDB for scripture embeddings
- ✅ Ready for frontend integration (Streamlit or HTML)
- ✅ Simple `.env` for secure API key usage

## Setup Instructions
1. Install required packages:
   ```
   pip install fastapi openai langchain chromadb python-dotenv uvicorn
   ```

2. Add your OpenAI API key to `.env`:
   ```
   OPENAI_API_KEY=your_key_here
   ```

3. Run the app:
   ```
   uvicorn main:app --reload
   ```

4. Ask questions via `/ask` endpoint (POST with JSON: {"question": "..."})

---

### Sample File Loaded
The app comes with a sample `jesus.txt` file inside `/texts`. You can add any spiritual or historical text you'd like for richer answers.

---

Built for researchers, seekers, truth tellers, and thinkers.

> “You shall know the truth, and the truth shall set you free.” — John 8:32
