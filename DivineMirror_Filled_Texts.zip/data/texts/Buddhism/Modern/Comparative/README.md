# Buddhism - Modern - Comparative

Directory for comparative texts from the modern period of Buddhism.

## Purpose
Contains comparative analysis with other traditions and periods.
