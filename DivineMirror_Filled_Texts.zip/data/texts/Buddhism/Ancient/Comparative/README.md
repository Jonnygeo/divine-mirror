# Buddhism - Ancient - Comparative

Directory for comparative texts from the ancient period of Buddhism.

## Purpose
Contains comparative analysis with other traditions and periods.
