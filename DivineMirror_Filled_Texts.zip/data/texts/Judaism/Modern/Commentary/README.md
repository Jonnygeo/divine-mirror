# Judaism - Modern - Commentary

Directory for commentary texts from the modern period of Judaism.

## Purpose
Contains scholarly analysis and commentary on the texts.
