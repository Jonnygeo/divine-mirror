# Judaism - Medieval - Commentary

Directory for commentary texts from the medieval period of Judaism.

## Purpose
Contains scholarly analysis and commentary on the texts.
