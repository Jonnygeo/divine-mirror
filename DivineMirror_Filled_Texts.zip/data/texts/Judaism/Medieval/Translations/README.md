# Judaism - Medieval - Translations

Directory for translations texts from the medieval period of Judaism.

## Purpose
Contains translations into various languages and historical periods.
