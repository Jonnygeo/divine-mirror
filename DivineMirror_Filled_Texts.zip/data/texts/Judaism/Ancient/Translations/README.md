# Judaism - Ancient - Translations

Directory for translations texts from the ancient period of Judaism.

## Purpose
Contains translations into various languages and historical periods.
