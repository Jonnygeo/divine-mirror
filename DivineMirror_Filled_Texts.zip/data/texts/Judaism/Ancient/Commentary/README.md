# Judaism - Ancient - Commentary

Directory for commentary texts from the ancient period of Judaism.

## Purpose
Contains scholarly analysis and commentary on the texts.
