# Judaism - Ancient - Comparative

Directory for comparative texts from the ancient period of Judaism.

## Purpose
Contains comparative analysis with other traditions and periods.
