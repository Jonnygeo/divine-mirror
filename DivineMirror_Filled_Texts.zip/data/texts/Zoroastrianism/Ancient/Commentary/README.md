# Zoroastrianism - Ancient - Commentary

Directory for commentary texts from the ancient period of Zoroastrianism.

## Purpose
Contains scholarly analysis and commentary on the texts.
