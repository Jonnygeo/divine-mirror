# Zoroastrianism - Modern - Original

Directory for original texts from the modern period of Zoroastrianism.

## Purpose
Contains texts in their original languages and earliest available forms.
