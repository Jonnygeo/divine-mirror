# Zoroastrianism - Medieval - Original

Directory for original texts from the medieval period of Zoroastrianism.

## Purpose
Contains texts in their original languages and earliest available forms.
