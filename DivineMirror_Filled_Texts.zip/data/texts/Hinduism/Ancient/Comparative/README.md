# Hinduism - Ancient - Comparative

Directory for comparative texts from the ancient period of Hinduism.

## Purpose
Contains comparative analysis with other traditions and periods.
