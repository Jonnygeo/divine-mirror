# Hinduism - Ancient - Commentary

Directory for commentary texts from the ancient period of Hinduism.

## Purpose
Contains scholarly analysis and commentary on the texts.
