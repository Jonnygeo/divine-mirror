# Hinduism - Ancient - Original

Directory for original texts from the ancient period of Hinduism.

## Purpose
Contains texts in their original languages and earliest available forms.
