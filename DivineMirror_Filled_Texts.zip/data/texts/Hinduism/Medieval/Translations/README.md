# Hinduism - Medieval - Translations

Directory for translations texts from the medieval period of Hinduism.

## Purpose
Contains translations into various languages and historical periods.
