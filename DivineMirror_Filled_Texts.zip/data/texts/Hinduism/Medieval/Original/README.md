# Hinduism - Medieval - Original

Directory for original texts from the medieval period of Hinduism.

## Purpose
Contains texts in their original languages and earliest available forms.
