# Hinduism - Modern - Translations

Directory for translations texts from the modern period of Hinduism.

## Purpose
Contains translations into various languages and historical periods.
