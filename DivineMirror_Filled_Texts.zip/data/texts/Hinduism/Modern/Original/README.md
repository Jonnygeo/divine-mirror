# Hinduism - Modern - Original

Directory for original texts from the modern period of Hinduism.

## Purpose
Contains texts in their original languages and earliest available forms.
