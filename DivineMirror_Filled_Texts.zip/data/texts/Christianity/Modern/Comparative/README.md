# Christianity - Modern - Comparative

Directory for comparative texts from the modern period of Christianity.

## Purpose
Contains comparative analysis with other traditions and periods.
