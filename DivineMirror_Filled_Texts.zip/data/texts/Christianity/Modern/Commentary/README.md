# Christianity - Modern - Commentary

Directory for commentary texts from the modern period of Christianity.

## Purpose
Contains scholarly analysis and commentary on the texts.
