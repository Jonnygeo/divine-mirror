# Christianity - Modern - Original

Directory for original texts from the modern period of Christianity.

## Purpose
Contains texts in their original languages and earliest available forms.
