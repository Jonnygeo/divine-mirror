# Christianity - Ancient - Translations

Directory for translations texts from the ancient period of Christianity.

## Purpose
Contains translations into various languages and historical periods.
