# Christianity - Ancient - Commentary

Directory for commentary texts from the ancient period of Christianity.

## Purpose
Contains scholarly analysis and commentary on the texts.
