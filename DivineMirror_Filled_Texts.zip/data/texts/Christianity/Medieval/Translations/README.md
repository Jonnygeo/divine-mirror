# Christianity - Medieval - Translations

Directory for translations texts from the medieval period of Christianity.

## Purpose
Contains translations into various languages and historical periods.
