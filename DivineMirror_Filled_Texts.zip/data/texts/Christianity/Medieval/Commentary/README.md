# Christianity - Medieval - Commentary

Directory for commentary texts from the medieval period of Christianity.

## Purpose
Contains scholarly analysis and commentary on the texts.
