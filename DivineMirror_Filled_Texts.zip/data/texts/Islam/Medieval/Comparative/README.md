# Islam - Medieval - Comparative

Directory for comparative texts from the medieval period of Islam.

## Purpose
Contains comparative analysis with other traditions and periods.
