# Islam - Medieval - Original

Directory for original texts from the medieval period of Islam.

## Purpose
Contains texts in their original languages and earliest available forms.
