# Islam - Medieval - Commentary

Directory for commentary texts from the medieval period of Islam.

## Purpose
Contains scholarly analysis and commentary on the texts.
