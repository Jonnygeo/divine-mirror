# Taoism - Medieval - Translations

Directory for translations texts from the medieval period of Taoism.

## Purpose
Contains translations into various languages and historical periods.
