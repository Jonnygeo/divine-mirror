# Taoism - Medieval - Original

Directory for original texts from the medieval period of Taoism.

## Purpose
Contains texts in their original languages and earliest available forms.
