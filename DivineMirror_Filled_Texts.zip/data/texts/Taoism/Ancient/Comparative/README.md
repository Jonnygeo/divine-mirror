# Taoism - Ancient - Comparative

Directory for comparative texts from the ancient period of Taoism.

## Purpose
Contains comparative analysis with other traditions and periods.
