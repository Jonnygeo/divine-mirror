# Taoism - Ancient - Commentary

Directory for commentary texts from the ancient period of Taoism.

## Purpose
Contains scholarly analysis and commentary on the texts.
