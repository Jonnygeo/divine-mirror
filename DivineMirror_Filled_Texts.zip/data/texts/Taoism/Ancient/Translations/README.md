# Taoism - Ancient - Translations

Directory for translations texts from the ancient period of Taoism.

## Purpose
Contains translations into various languages and historical periods.
